import os
from _io import open
from Model.Klase import Osoba, Film, SalaProjekcije, BioskopskaProjekcija, BioskopskaKarta, TerminProjekcije, Rezervacija
from datetime import datetime


def citanje_korisnika():
    korisnici = []
    path="C:/Users/nemanja97/PythonProjekat/txt_fajlovi"
    filename=os.path.join(path,"korisnici.txt")
    with open(filename, "r") as f:
        for linija in f:
            polja = linija.strip().split("|")
            korisnicko_ime = polja[0]
            lozinka = polja[1]
            ime = polja[2]
            prezime = polja[3]
            uloga = polja[4]
            korisnici.append(Osoba(korisnicko_ime, lozinka, ime, prezime, uloga))
    return korisnici

def citanje_filmova():
    filmovi = []
    path="C:/Users/nemanja97/PythonProjekat/txt_fajlovi"
    filename=os.path.join(path,"film.txt")
    with open(filename, "r") as f:
        for linija in f:
            polja = linija.strip().split("|")
            naziv = polja[0]
            zanr = polja[1]
            trajanje = int(polja[2])
            reziser = polja[3]
            glavne_uloge = polja[4].rstrip(",").split(",")
            zemlja_porekla = polja[5]
            godina_proizvodnje = int(polja[6])
            skraceni_opis_filma = polja[7]
            filmovi.append(Film(naziv, zanr, trajanje, reziser, glavne_uloge, zemlja_porekla, godina_proizvodnje, skraceni_opis_filma))
    return filmovi

def citanje_sala_projekcije():
    sale_projekcije = []
    path="C:/Users/nemanja97/PythonProjekat/txt_fajlovi"
    filename=os.path.join(path,"sala_projekcije.txt")
    with open(filename, "r") as f:
        for linija in f:
            polja = linija.strip().split("|")
            sifra_sale = polja[0]
            naziv_sale = polja[1]
            broj_redova = int(polja[2])
            oznaka_sedista = polja[3].rstrip(",").split(",")
            sale_projekcije.append(SalaProjekcije(sifra_sale, naziv_sale, broj_redova, oznaka_sedista))
    return sale_projekcije

def citanje_bioskopske_projekcije():
    bioskop_projekcije = []
    path="C:/Users/nemanja97/PythonProjekat/txt_fajlovi"
    filename=os.path.join(path,"bioskopska_projekcija.txt")
    with open(filename, "r") as f:
        for linija in f:
            polja = linija.strip().split("|")
            sifra = polja[0]
            sala = polja[1]
            vreme_pocetka = polja[2]
            vreme_kraja = polja[3]
            dani_odrzavanja = polja[4].rstrip(",").split(",")
            film_prikazivanje = polja[5]
            cena_karte = float(polja[6])
            bioskop_projekcije.append(BioskopskaProjekcija(sifra, sala, vreme_pocetka, vreme_kraja, dani_odrzavanja, film_prikazivanje, cena_karte))
    return bioskop_projekcije

def citanje_bioskopske_karte():
    bioskop_karte = []
    path="C:/Users/nemanja97/PythonProjekat/txt_fajlovi"
    filename=os.path.join(path,"bioskopska_karte.txt")
    with open(filename, "r") as f:
        for linija in f:
            polja = linija.strip().split("|")
            redni_broj = polja[0]
            ime = polja[1]
            prezime = polja[2]
            korisnicko_ime = polja[3]
            termin_projekcije = polja[4]
            sifra_sale = polja[5]
            red_sedista = polja[6]
            oznaka_sedista = polja[7]
            datum_prodaje = polja[8]
            rezervisano_kupljeno = polja[9]
            prodavac = polja[10]
            bioskop_karte.append(BioskopskaKarta(redni_broj, ime, prezime, korisnicko_ime, termin_projekcije, sifra_sale, red_sedista, oznaka_sedista, datum_prodaje, rezervisano_kupljeno, prodavac))
    return bioskop_karte

def citanje_termina_projekcije():
    termini_projekcije = []
    path="C:/Users/nemanja97/PythonProjekat/txt_fajlovi"
    filename=os.path.join(path,"termin_projekcije.txt")
    with open(filename, "r") as f:
        for linija in f:
            polja = linija.strip().split("|")
            sifra_termina = polja[0]
            datum_odrzavanja = polja[1]
            termini_projekcije.append(TerminProjekcije(sifra_termina, datum_odrzavanja))
    return termini_projekcije

def citanje_rezervacije_karte():
    rezervacije = []
    path = "C:/Users/nemanja97/PythonProjekat/txt_fajlovi"
    filename=os.path.join(path, "rezervacija_karte.txt")
    with open(filename, "r") as f:
        for linija in f:
            polja = linija.strip().split("|")
            redni_broj = polja[0]
            sifra_termina = polja[1]
            sifra_sale = polja[2]
            red_sedista = polja[3]
            oznaka_sedista = polja[4]
            kupac = polja[5]
            rezervacije.append(Rezervacija(redni_broj, sifra_termina, sifra_sale, red_sedista, oznaka_sedista, kupac))
    return rezervacije