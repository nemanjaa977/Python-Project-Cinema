import os

def upis_osoba(korisnici):
    path="C:/Users/nemanja97/PythonProjekat/txt_fajlovi"
    filename=os.path.join(path,"korisnici.txt")
    with open(filename, "w") as f:
        for k in korisnici:
            f.write("{}|".format(k.korisnicko_ime))
            f.write("{}|".format(k.lozinka))
            f.write("{}|".format(k.ime))
            f.write("{}|".format(k.prezime))
            f.write("{}|\n".format(k.uloga))

def upis_filmova(film):
    path="C:/Users/nemanja97/PythonProjekat/txt_fajlovi"
    filename=os.path.join(path,"film.txt")
    with open(filename, "w") as f:
        for fi in film:
            f.write("{}|".format(fi.naziv))
            f.write("{}|".format(fi.zanr))
            f.write("{}|".format(fi.trajanje))
            f.write("{}|".format(fi.reziser))
            for glumac in fi.glavne_uloge:
                f.write("{},".format(glumac))
            f.write("|{}|".format(fi.zemlja_porekla))
            f.write("{}|".format(fi.godina_proizvodnje))
            f.write("{}|\n".format(fi.skraceni_opis_filma))

def upis_projekcija(projekcija):
    path="C:/Users/nemanja97/PythonProjekat/txt_fajlovi"
    filename=os.path.join(path,"bioskopska_projekcija.txt")
    with open(filename, "w") as f:
        for p in projekcija:
            f.write("{}|".format(p.sifra))
            f.write("{}|".format(p.sala))
            f.write("{}|".format(p.vreme_pocetka))
            f.write("{}|".format(p.vreme_kraja))
            for dan in p.dani_odrzavanja:
                f.write("{},".format(dan))
            f.write("|{}|".format(p.film_prikazivanje))
            f.write("{}|\n".format(p.cena_karte))

def upis_sale(sale):
    path="C:/Users/nemanja97/PythonProjekat/txt_fajlovi"
    filename=os.path.join(path,"sala_projekcije.txt")
    with open(filename, "w") as f:
        for k in sale:
            f.write("{}|".format(k.sifra_sale))
            f.write("{}|".format(k.naziv_sale))
            f.write("{}|".format(k.broj_redova))
            for oznaka in k.oznaka_sedista:
                 f.write("{},".format(oznaka))
            f.write("| \n")

def upis_termina(termini):
    path="C:/Users/nemanja97/PythonProjekat/txt_fajlovi"
    filename=os.path.join(path,"termin_projekcije.txt")
    with open(filename, "w") as f:
        for k in termini:
            f.write("{}|".format(k.sifra_termina))
            f.write("{}|\n".format(k.datum_odrzavanja))

def upis_rezervacije_karte(reze):
    path="C:/Users/nemanja97/PythonProjekat/txt_fajlovi"
    filename=os.path.join(path,"rezervacija_karte.txt")
    with open(filename, "w") as f:
        for k in reze:
            f.write("{}|".format(k.redni_broj))
            f.write("{}|".format(k.sifra_termina))
            f.write("{}|".format(k.sifra_sale))
            f.write("{}|".format(k.red_sedista))
            f.write("{}|".format(k.oznaka_sedista))
            f.write("{}|\n".format(k.kupac))

def upis_bioskopske_karte(karte):
    path="C:/Users/nemanja97/PythonProjekat/txt_fajlovi"
    filename=os.path.join(path,"bioskopska_karte.txt")
    with open(filename, "w") as f:
        for k in karte:
            f.write("{}|".format(k.redni_broj))
            f.write("{}|".format(k.ime))
            f.write("{}|".format(k.prezime))
            f.write("{}|".format(k.korisnicko_ime))
            f.write("{}|".format(k.termin_projekcije))
            f.write("{}|".format(k.sifra_sale))
            f.write("{}|".format(k.red_sedista))
            f.write("{}|".format(k.oznaka_sedista))
            f.write("{}|".format(k.datum_prodaje))
            f.write("{}|".format(k.rezervisano_kupljeno))
            f.write("{}|\n".format(k.prodavac))

