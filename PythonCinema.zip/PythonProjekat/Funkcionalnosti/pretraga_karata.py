from Ucitavanje.citanje_iz_fajla import citanje_bioskopske_karte
from Funkcionalnosti.dodatno import prikaz_menija, provera_unosa
from Funkcionalnosti.kupac import pronadji_bio_projekciju

def prikaz_karti(karte):
    zaglavlje = "|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|".format("Redni broj", "Ime", "Prezime",
                            "Sifra termina", "Red sedista", "Oznaka sedista", "Korisnicko ime", "Datum prodaje", "Nacin")
    s = len(zaglavlje)
    print(zaglavlje)
    print("-" * s)
    for l in karte:
        print("|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|".format(l.redni_broj, l.ime, l.prezime,
                                                                                 l.termin_projekcije, l.red_sedista,
                                                                                 l.oznaka_sedista, l.korisnicko_ime,
                                                                                 l.datum_prodaje, l.rezervisano_kupljeno))

def pretraga_karti():
    while True:
        prikaz_menija("Pretraga filmova:","1 - po sifri projekcije", "2 - po imenu", "3 - po korisnickom imenu kupca", "4 - po datumu prodaje",
                      "5 - po rezervaciji/kupovini", "6 - po prezimenu ","7 - Izlaz")
        opcija=provera_unosa("Opcija:","Opcija mora biti celobrojna vrednost",int)
        if opcija==7:
            break
        elif opcija==1:
            sifra = input("Unesite sifru projekcije za pretragu: ")
            pronadjeni = pretraga_po_sifri_projekcije(sifra)
            prikaz_karti(pronadjeni)
        elif opcija==2:
            naziv = input("Unesite ime za pretragu: ")
            pronadjeni = pretraga_po_imenu(naziv)
            prikaz_karti(pronadjeni)
        elif opcija==3:
            naziv = input("Unesite korisnicko ime za pretragu: ")
            pronadjeni = pretraga_po_korisnickom_imenu(naziv)
            prikaz_karti(pronadjeni)
        elif opcija==4:
            naziv = input("Unesite datum prodaje za pretragu: ")
            pronadjeni = pretraga_po_datumu_prodaje(naziv)
            prikaz_karti(pronadjeni)
        elif opcija==5:
            naziv = input("Unesite rezervisano/prodato za pretragu: ")
            pronadjeni = pretraga_po_rez_kup(naziv)
            prikaz_karti(pronadjeni)
        elif opcija==6:
            naziv = input("Unesite prezime za pretragu: ")
            pronadjeni = pretraga_po_prezimenu(naziv)
            prikaz_karti(pronadjeni)

def pretraga_po_imenu(naziv):
    pronadjeni=[]
    karte = citanje_bioskopske_karte()
    for f in karte:
        if naziv.lower() in f.ime.lower():
            pronadjeni.append(f)
    return pronadjeni

def pretraga_po_korisnickom_imenu(naziv):
    pronadjeni=[]
    karte = citanje_bioskopske_karte()
    for f in karte:
        if naziv.lower() in f.korisnicko_ime.lower():
            pronadjeni.append(f)
    return pronadjeni

def pretraga_po_rez_kup(naziv):
    pronadjeni=[]
    karte = citanje_bioskopske_karte()
    for f in karte:
        if naziv.lower() in f.rezervisano_kupljeno.lower():
            pronadjeni.append(f)
    return pronadjeni

def pretraga_po_datumu_prodaje(naziv):
    pronadjeni=[]
    karte = citanje_bioskopske_karte()
    for f in karte:
        if naziv.lower() in f.datum_prodaje.lower():
            pronadjeni.append(f)
    return pronadjeni

def pretraga_po_prezimenu(naziv):
    pronadjeni=[]
    karte = citanje_bioskopske_karte()
    for f in karte:
        if naziv.lower() in f.prezime.lower():
            pronadjeni.append(f)
    return pronadjeni

def pretraga_po_sifri_projekcije(sifra):
    pronadjeni = []
    karte = citanje_bioskopske_karte()
    for f in karte:
        if sifra.lower() in f.termin_projekcije[:4].lower():
            pronadjeni.append(f)
    return pronadjeni