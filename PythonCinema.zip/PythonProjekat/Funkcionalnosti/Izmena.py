from Funkcionalnosti.dodatno import prikaz_menija, provera_unosa
from Ucitavanje.citanje_iz_fajla import citanje_filmova, citanje_bioskopske_projekcije,citanje_sala_projekcije,citanje_termina_projekcije
from Ucitavanje.pisanje_u_fajl import upis_filmova, upis_sale, upis_projekcija, upis_termina
from Funkcionalnosti.film import prikaz_filmova
from Funkcionalnosti.b_projekcija import prikaz_projekcija
from Funkcionalnosti.sala_termin import prikaz_termina, prikaz_sala
from Funkcionalnosti.Unos import format_vremena, p_datum, dodavanje_termina_projekcije
from datetime import datetime

def meni_izmena():
    while True:
        prikaz_menija("Izaberite opciju: ", "1 - Izmena bioskopske projekcije", "2 - Izmena sale za projekciju",
                      "3 - Izmena filma", "4 - Izmena termina projekcije","5 - Izlaz")
        opcija = provera_unosa("Opcija:", "Opcija mora biti celobrojna vrednost", int)
        if opcija == 5:
            break
        elif opcija == 1:
            izmena_bioskopske_projekcije()
        elif opcija == 2:
            izmena_sale()
        elif opcija == 3:
            izmena_filma()
        elif opcija == 4:
            izmena_termina_projekcije()

def izmena_bioskopske_projekcije():
    try:
        projekcije = citanje_bioskopske_projekcije()
        prikaz_projekcija(projekcije)
        oznaka = input("Unesite sifru projekcije koju zelite da izmenite: \n")
        for f in projekcije:
            if oznaka == f.sifra:
                izmena = f
                print()
                print("\nParametri za menjanje:\n1 - Sala\n2 - Vreme pocetka\n3 - Vreme kraja\n4 - Dani odrzavanja uloge\n5 - Film\n6 - Cena karte\n7 - Izlaz")
                izbor = input("Izaberite opciju: ")
                while izbor.upper() not in ("1", "2", "3", "4", "5", "6", "7"):
                    print("\nUneli ste pogresnu opciju!\n")
                    izbor = input("Izaberite opciju: ")
                if izbor == "1":
                    sal = citanje_sala_projekcije()
                    prikaz_sala(sal)
                    sala2 = input("Unesite salu za izmenu: ")
                    list = []
                    for j in sal:
                        list.append(j.sifra_sale)
                    while list.__contains__(sala2) == False:
                        print("Izabrana sala ne postoji!")
                        sala2 = input("Sifra sale: ")
                    izmena.sala = sala2
                    upis_projekcija(projekcije)
                elif izbor == "2":
                    pocetak2 = input("Unesite vreme pocetka za izmenu: ")
                    while format_vremena(pocetak2) == False:
                        print("Vreme mora biti u formatu HH:mm !")
                        pocetak2 = input("Vreme pocetka: ")
                    izmena.vreme_pocetka = pocetak2
                    upis_projekcija(projekcije)
                elif izbor == "3":
                    kraj2 = input("Unesite vreme kraja za izmenu: ")
                    while format_vremena(kraj2) == False:
                        print("Vreme mora biti u formatu HH:mm !")
                        kraj2 = input("Vreme pocetka: ")
                    izmena.vreme_kraja = kraj2
                    upis_projekcija(projekcije)
                elif izbor == "4":
                    jos_dana = True
                    danii = ["Ponedeljak", "Utorak", "Sreda", "Cetvrtak", "Petak", "Subota", "Nedelja"]
                    dani_odrzavanja = []
                    while jos_dana == True:
                        dani2 = input("Dan u nedelji: ")
                        while dani2.capitalize() not in danii:
                            print("Izabrali ste ne postojeci dan u nedelji!")
                            dani2 = input("Dan u nedelji: ")
                        dani_odrzavanja.append(dani2)
                        ima_jos_str = input("Da li ima jos [y/n]?")
                        if ima_jos_str == 'n':
                            break
                    izmena.dani_odrzavanja = dani_odrzavanja
                    upis_projekcija(projekcije)
                elif izbor == "5":
                     filmovi = citanje_filmova()
                     prikaz_filmova(filmovi)
                     film2 = input("Unesite naziv filma za izmenu: ")
                     list = []
                     for d in filmovi:
                         list.append(d.naziv);
                     while list.__contains__(film2) == False:
                         print("Izabrani film ne postoji na repertoaru!")
                         film2 = input("Naziv filma: ")
                     izmena.film_prikazivanje = film2
                     upis_projekcija(projekcije)
                elif izbor == "7":
                    break
                elif izbor == "6":
                    try:
                        cena2 = float(input("Unesite cenu karte za izmenu: "))
                    except ValueError:
                        print("Uneti samo BROJ! Pokusajte ponovo!")
                        cena2 = float(input("Unesite cenu karte za izmenu: "))
                    izmena.cena_karte = cena2
                    upis_projekcija(projekcije)
                    return True
    except Exception as e:
        print(e)

def izmena_sale():
    try:
        sale = citanje_sala_projekcije()
        prikaz_sala(sale)
        oznaka = input("Unesite sifru sale koju zelite da izmenite: \n")
        for f in sale:
            if oznaka == f.sifra_sale:
                izmena = f
                print()
                print("\nParametri za menjanje:\n1 - Naziv\n2 - Broj redova\n3 - Izlaz")
                izbor = input("Izaberite opciju: ")
                while izbor.upper() not in ("1", "2", "3"):
                    print("\nUneli ste pogresnu opciju!\n")
                    izbor = input("Izaberite opciju: ")
                if izbor == "1":
                    naziv2 = input("Unesite naziv za izmenu: ")
                    izmena.naziv_sale = naziv2
                    upis_sale(sale)
                elif izbor == "3":
                    break
                elif izbor == "2":
                    try:
                        broj2 = int(input("Unesite broj redova za izmenu: "))
                        while broj2 > 10:
                            print("Uneta vrednost mora biti ceo broj! (int)")
                            broj2 = int(input("Unesite broj redova za izmenu: "))
                    except ValueError:
                        print("Uneta vrednost mora biti ceo broj! (int)")
                        broj2 = int(input("Broj redova: "))
                    izmena.broj_redova = broj2
                    upis_sale(sale)
                    return True
    except Exception as e:
        print(e)

def izmena_filma():
    try:
        filmovi = citanje_filmova()
        prikaz_filmova(filmovi)
        oznaka = input("Unesite naziv filma koji zelite da izmenite: \n")
        for f in filmovi:
            if oznaka == f.naziv:
                izmena = f
                print()
                print("\nParametri za menjanje:\n1 - Naziv\n2 - Zanr\n3 - Trajanje\n4 - Reziser\n5 - Glavne uloge\n6 - Zemlja porekla\n7 - Godina proizvodnje\n8 - Skraceni opis filma\n9 - Izlaz")
                izbor = input("Izaberite opciju: ")
                while izbor.upper() not in ("1", "2", "3", "4", "5", "6", "7", "8", "9"):
                    print("\nUneli ste pogresnu opciju!\n")
                    izbor = input("Izaberite opciju: ")
                if izbor == "1":
                    naziv2 = input("Unesite naziv za izmenu: ")
                    izmena.naziv = naziv2
                    upis_filmova(filmovi)
                elif izbor == "2":
                    zanr2 = input("Unesite zanr za izmenu: ")
                    izmena.zanr = zanr2
                    upis_filmova(filmovi)
                elif izbor == "3":
                    try:
                        trajanje2 = int(input("Unesite trajanje filma za izmenu: "))
                    except ValueError:
                        print("Trajanje mora biti ceo broj! (Izrazeno u minutima)")
                        trajanje2 = int(input("Unesite trajanje filma za izmenu: "))
                    izmena.trajanje = trajanje2
                    upis_filmova(filmovi)
                elif izbor == "4":
                    reziser2 = input("Unesite rezisera za izmenu: ")
                    izmena.reziser = reziser2
                    upis_filmova(filmovi)
                elif izbor == "5":
                    ima_jos = True
                    glavne_ulogee = []
                    while ima_jos == True:
                        glavna_uloga2 = input("Glavna uloga za izmenu: ")
                        glavne_ulogee.append(glavna_uloga2)
                        ima_jos_str = input("Da li ima jos [y/n]?")
                        if ima_jos_str == 'n':
                            break
                    izmena.glavne_uloge = glavne_ulogee
                    upis_filmova(filmovi)
                elif izbor == "6":
                    zemlja_porekla2 = input("Unesite zemlju porekla za izmenu: ")
                    izmena.zemlja_porekla = zemlja_porekla2
                    upis_filmova(filmovi)
                elif izbor == "7":
                    try:
                        godina_proizvodnje2 = int(input("Unesite godinu proizvodnje za izmenu: "))
                        while godina_proizvodnje2 > 2018:
                            print("Izabrana godina jos nije pocela. Nemoguce izabrati!")
                            godina_proizvodnje2 = int(input("Godina proizvodnje: "))
                    except ValueError:
                        print("Godina mora biti ceo broj! (int)")
                        godina_proizvodnje2 = int(input("Unesite godinu proizvodnje za izmenu: "))
                    izmena.godina_proizvodnje = godina_proizvodnje2
                    upis_filmova(filmovi)
                elif izbor == "9":
                    break
                elif izbor == "8":
                    skraceni_opis_filma2 = input("Unesite skraceni opis filma za izmenu: ")
                    izmena.skraceni_opis_filma = skraceni_opis_filma2
                    upis_filmova(filmovi)
                    return True
    except Exception as e:
        print(e)

def izmena_termina_projekcije():
    try:
        termini = citanje_termina_projekcije()
        prikaz_termina(termini)
        oznaka = input("Unesite sifru termina koji zelite da izmenite: \n")
        for f in termini:
            if oznaka == f.sifra_termina:
                izmena = f
                print()
                print("\nParametri za menjanje:\n1 - Datum odrzavanja\n2 - Izlaz")
                izbor = input("Izaberite opciju: ")
                while izbor.upper() not in ("1", "2"):
                    print("\nUneli ste pogresnu opciju!\n")
                    izbor = input("Izaberite opciju: ")
                if izbor == "2":
                    break
                elif izbor == "1":
                    try:
                        datum_odrzavanja = input("Unesite datum odrzavanja(dd.mm.yyyy.): ")
                        datum_neparsiran = p_datum(datum_odrzavanja)
                        datum_parsiran = datetime.__format__(datum_neparsiran, "%d.%m.%Y.")
                    except ValueError:
                        try:
                            print("Datum mora biti formata dd.mm.YYYY.")
                            datum_odrzavanja = input("Unesite datum odrzavanja(dd.mm.yyyy.): ")
                            datum_neparsiran = p_datum(datum_odrzavanja)
                            datum_parsiran = datetime.__format__(datum_neparsiran, "%d.%m.%Y.")
                        except ValueError:
                            print("\nZao nam je ,zbog prevelikog broja gresaka morate sve iz pocetka\n")
                            dodavanje_termina_projekcije()
                    izmena.datum_odrzavanja = datum_parsiran
                    upis_termina(termini)
                    return True
    except Exception as e:
        print(e)