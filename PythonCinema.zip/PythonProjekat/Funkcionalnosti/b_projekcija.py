from Funkcionalnosti.dodatno import prikaz_menija, provera_unosa
from Ucitavanje.citanje_iz_fajla import citanje_bioskopske_projekcije

def prikaz_projekcija(projekcije):
    zaglavlje = "|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^20s}|{:^15s}|{:^15s}|".format("Sifra", "Sala", "Vreme pocetka",
                                                        "Vreme kraja", "Dani", "Film", "Cena karte")
    s = len(zaglavlje)
    print(zaglavlje)
    print("-"*s)
    for f in projekcije:
        print("|{:^15s}|{:^15s}|{:^15s}|{:^15s}|".format(f.sifra, f.sala, f.vreme_pocetka, f.vreme_kraja), end="")

        for i in range(len(f.dani_odrzavanja)):
            if i == len(f.dani_odrzavanja) - 1 :
                print("{} ".format(f.dani_odrzavanja[i]), end="")
                break
            print("{}, ".format(f.dani_odrzavanja[i]), end="")
        print("|{:^15s}|{:^15f}|".format(f.film_prikazivanje, f.cena_karte))

def pretraga_projekcija():
    while True:
        prikaz_menija("Pretraga bioskopskih projekcija:","1 - po sifri","2 - po sali ","3 - po vremenu pocetka","4 - po vremenu kraja",
                      "5 - po danima u nedelji","6 - po filmu prikazivanja", "7 - po ceni karte","8 - Izlaz")
        opcija=provera_unosa("Opcija:","Opcija mora biti celobrojna vrednost",int)
        if opcija==8:
            break
        elif opcija==1:
            sifra=input("Unesite sifru projkcije za pretragu: ")
            pronadjeni = pretraga_po_sifri(sifra)
            prikaz_projekcija(pronadjeni)
        elif opcija==2:
            sala=input("Unesite salu za pretragu: ")
            pronadjeni = pretraga_po_sali(sala)
            prikaz_projekcija(pronadjeni)
        elif opcija==3:
            pocetak = input("Unesite vreme pocetka za pretragu: ")
            pronadjeni = pretraga_po_v_pocetka(pocetak)
            prikaz_projekcija(pronadjeni)
        elif opcija==4:
            kraj = input("Unesite vreme kraja za pretragu: ")
            pronadjeni = pretraga_po_v_kraja(kraj)
            prikaz_projekcija(pronadjeni)
        elif opcija==5:
            dani = input("Unesite dan u nedelji za pretragu: ")
            pronadjeni = pretraga_po_danima(dani)
            prikaz_projekcija(pronadjeni)
        elif opcija==6:
            filmm=input("Unesite film za pretragu: ")
            pronadjeni = pretraga_po_filmu(filmm)
            prikaz_projekcija(pronadjeni)
        elif opcija==7:
            cena=input("Unesite cenu karte za pretragu: ")
            pronadjeni = pretraga_po_ceni(cena)
            prikaz_projekcija(pronadjeni)

def pretraga_po_sifri(sifra):
    pronadjeni=[]
    projekcije=citanje_bioskopske_projekcije()
    for f in projekcije:
        if sifra.lower() in f.sifra.lower():
            pronadjeni.append(f)
    return pronadjeni

def pretraga_po_sali(sala):
    pronadjeni=[]
    projekcije=citanje_bioskopske_projekcije()
    for f in projekcije:
        if sala.lower() in f.sala.lower():
            pronadjeni.append(f)
    return pronadjeni

def pretraga_po_v_pocetka(vreme_pocetka):
    pronadjeni=[]
    projekcije=citanje_bioskopske_projekcije()
    for f in projekcije:
        if vreme_pocetka.lower() in f.vreme_pocetka.lower():
            pronadjeni.append(f)
    return pronadjeni

def pretraga_po_v_kraja(vreme_kraja):
    pronadjeni=[]
    projekcije=citanje_bioskopske_projekcije()
    for f in projekcije:
        if vreme_kraja.lower() in f.vreme_kraja.lower():
            pronadjeni.append(f)
    return pronadjeni

def pretraga_po_danima(dani_odrzavanja):
    pronadjeni=[]
    projekcije = citanje_bioskopske_projekcije()
    for f in projekcije:
        for dan in f.dani_odrzavanja:
            if dani_odrzavanja.lower() in dan.lower():
               pronadjeni.append(f)
    return pronadjeni

def pretraga_po_filmu(film_prikazivanja):
    pronadjeni=[]
    projekcije=citanje_bioskopske_projekcije()
    for f in projekcije:
        if film_prikazivanja.lower() in f.film_prikazivanje.lower():
            pronadjeni.append(f)
    return pronadjeni

def pretraga_po_ceni(cena_karte):
    pronadjeni=[]
    projekcije=citanje_bioskopske_projekcije()
    for f in projekcije:
        if cena_karte in str(f.cena_karte):
            pronadjeni.append(f)
    return pronadjeni