

def prikaz_sala(sale):
    zaglavlje = "|{:^15s}|{:^15s}|{:^15s}|".format("Sifra", "Naziv", "Broj redova")
    s = len(zaglavlje)
    print(zaglavlje)
    print("-"*s)
    for l in sale:
        print("|{:^15s}|{:^15s}|{:^15d}|".format(l.sifra_sale, l.naziv_sale, l.broj_redova))

def prikaz_termina(term):
    zaglavlje = "|{:^15s}|{:^15s}|".format("Sifra", "Datum odrzavanja")
    s = len(zaglavlje)
    print(zaglavlje)
    print("-"*s)
    for t in term:
        print("|{:^15s}|{:^15s}|".format(t.sifra_termina, t.datum_odrzavanja))
