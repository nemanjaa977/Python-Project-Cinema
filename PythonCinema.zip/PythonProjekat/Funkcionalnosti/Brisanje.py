from Funkcionalnosti.dodatno import prikaz_menija, provera_unosa
from Ucitavanje.citanje_iz_fajla import citanje_filmova, citanje_bioskopske_projekcije, citanje_sala_projekcije, citanje_termina_projekcije, citanje_bioskopske_karte,citanje_rezervacije_karte
from Ucitavanje.pisanje_u_fajl import upis_filmova, upis_projekcija, upis_sale, upis_termina, upis_bioskopske_karte,upis_rezervacije_karte
from Funkcionalnosti.film import prikaz_filmova
from Funkcionalnosti.b_projekcija import prikaz_projekcija
from Funkcionalnosti.sala_termin import prikaz_sala, prikaz_termina
from Funkcionalnosti.kupac import pronadji_termin
from Funkcionalnosti.prodavac import pronadji_kartu_termin

def meni_brisanje():
    while True:
        prikaz_menija("Izaberite opciju: ", "1 - Brisanje bioskopske projekcije", "2 - Brisanje sale za projekciju",
                      "3 - Brisanje filma", "4 - Brisanje termina projekcije","5 - Izlaz")
        opcija = provera_unosa("Opcija:", "Opcija mora biti celobrojna vrednost", int)
        if opcija == 5:
            break
        elif opcija == 1:
            brisanje_projekcije()
        elif opcija == 2:
            brisanje_sale()
        elif opcija == 3:
            brisanje_filma()
        elif opcija == 4:
            brisanje_termina()

def brisanje_projekcije():
    projekcije = citanje_bioskopske_projekcije()
    karte=citanje_bioskopske_karte()
    termini=citanje_termina_projekcije()
    rezervacije=citanje_rezervacije_karte()
    prikaz_projekcija(projekcije)
    uneto = input("Unesite sifru bioskopske projekcije koju zelite da obrisete: ")
    list=[]
    for d in projekcije:
        list.append(d.sifra);
    while list.__contains__(uneto) == False:
        print("Izabrali ste ne postojecu sifru!")
        uneto = input("Unesite sifru bioskopske projekcije koju zelite da obrisete: ")
    for i in range(len(projekcije)):
        if uneto in projekcije[i].sifra:
            index=i
            termin=pronadji_termin(projekcije[i].sifra)
            termin_i=pronadji_indeks_termin(projekcije[i].sifra)
            karta=pronadji_indeks_kartu_termin(termin.sifra_termina)
            rezervacija=pronadji_indeks_rezervaciju_termn(termin.sifra_termina)

    if karta.__len__()>0:
        for x in sorted(karta,reverse=True):
            karte.pop(x)
    if termin_i.__len__()>0:
        for t in sorted(termin_i,reverse=True):
            termini.pop(t)
    if rezervacija.__len__()>0:
        for r in sorted(rezervacija, reverse=True):
            rezervacije.pop(r)

    projekcije.pop(index)
    upis_rezervacije_karte(rezervacije)
    upis_termina(termini)
    upis_bioskopske_karte(karte)
    upis_projekcija(projekcije)



def brisanje_sale():
    sale = citanje_sala_projekcije()
    projekcije = citanje_bioskopske_projekcije()
    rezervacije = citanje_rezervacije_karte()
    karte = citanje_bioskopske_karte()
    prikaz_sala(sale)
    uneto = input("Unesite sifru sale koju zelite da obrisete: ")
    list=[]
    for d in sale:
        list.append(d.sifra_sale);
    while list.__contains__(uneto) == False:
        print("Izabrali ste ne postojecu sifru sale!")
        uneto = input("Unesite sifru sale koju zelite da obrisete: ")
    for i in range(len(sale)):
        if uneto == sale[i].sifra_sale:
            index=i
            karta=pronadji_indeks_karta_sale(sale[i].sifra_sale)
            rezervacija=pronadji_indeks_rezervaciju_sala(sale[i].sifra_sale)
            projekcija=pronadji_projekcije_sale(sale[i].sifra_sale)

    if karta.__len__() > 0:
        for x in sorted(karta, reverse=True):
            karte.pop(x)
    if rezervacija.__len__()>0:
        for r in sorted(rezervacija, reverse=True):
            rezervacije.pop(r)

    for x in projekcije:
        if projekcija.__contains__(x.sifra):
            x.sala=None

    sale.pop(index)
    upis_rezervacije_karte(rezervacija)
    upis_bioskopske_karte(karta)
    upis_sale(sale)
    upis_projekcija(projekcije)

def brisanje_filma():
    filmovi = citanje_filmova()
    projekcije=citanje_bioskopske_projekcije()
    karte = citanje_bioskopske_karte()
    rezervacije = citanje_rezervacije_karte()
    prikaz_filmova(filmovi)
    uneto = input("Unesite naziv filma koji zelite da obrisete: ")
    list=[]
    for d in filmovi:
        list.append(d.naziv);
    while list.__contains__(uneto) == False:
        print("Izabrali ste ne postojeci film!")
        uneto = input("Unesite naziv filma koji zelite da obrisete: ")
    for i in range(len(filmovi)):
        if uneto == filmovi[i].naziv:
           index= i
           projekcija= pronadji_projekcije_film(filmovi[i].naziv)

    for x in projekcije:
        if projekcija.__contains__(x.sifra):
            x.film_prikazivanje=None
            karta=pronadji_indeks_kartu_termin(x.sifra)
            rezervacija=pronadji_indeks_rezervaciju_termn(x.sifra)

    if karta.__len__() > 0:
        for x in sorted(karta, reverse=True):
            karte.pop(x)

    if rezervacija.__len__() > 0:
        for r in sorted(rezervacija, reverse=True):
            rezervacije.pop(r)

    filmovi.pop(index)
    upis_filmova(filmovi)
    upis_projekcija(projekcije)
    upis_bioskopske_karte(karte)
    upis_rezervacije_karte(rezervacije)

def brisanje_termina():
    termini = citanje_termina_projekcije()
    rezervacije = citanje_rezervacije_karte()
    karte = citanje_bioskopske_karte()
    prikaz_termina(termini)
    uneto = input("Unesite sifru termina koji zelite da obrisete: ")
    list=[]
    for d in termini:
        list.append(d.sifra_termina);
    while list.__contains__(uneto) == False:
        print("Izabrali ste ne postojecu sifru termina!")
        uneto = input("Unesite sifru termina koji zelite da obrisete: ")
    for i in range(len(termini)):
        if uneto == termini[i].sifra_termina:
            index=i
            karta = pronadji_indeks_kartu_termin(termini[i].sifra_termina)
            rezervacija = pronadji_indeks_rezervaciju_termn(termini[i].sifra_termina)

    if karta.__len__()>0:
        for x in sorted(karta,reverse=True):
            karte.pop(x)
    if rezervacija.__len__()>0:
        for r in sorted(rezervacija, reverse=True):
            rezervacije.pop(r)

    termini.pop(index)
    upis_rezervacije_karte(rezervacije)
    upis_bioskopske_karte(karte)
    upis_termina(termini)

def pronadji_indeks_rezervaciju_termn(termin_s):
    rezervacije=citanje_rezervacije_karte()
    lista=[]
    for i in range(len(rezervacije)):
        if termin_s in rezervacije[i].sifra_termina:
            lista.append(i)

    return lista

def pronadji_indeks_termin(termin_s):
    termini=citanje_termina_projekcije()
    lista=[]
    for x in range(len(termini)):
        if termin_s in termini[x].sifra_termina:
            lista.append(x)

    return lista

def pronadji_indeks_kartu_termin(termin_s):
    karte=citanje_bioskopske_karte()
    lista=[]
    for x in range(len(karte)):
        if termin_s in karte[x].termin_projekcije:
            lista.append(x)

    return lista

def pronadji_indeks_rezervaciju_sala(sifra_s):
    rezervacije=citanje_rezervacije_karte()
    lista=[]
    for i in range(len(rezervacije)):
        if sifra_s in rezervacije[i].sifra_sale:
            lista.append(i)
    return lista

def pronadji_indeks_karta_sale(sifra_s):
    karte=citanje_bioskopske_karte()
    lista=[]
    for i in range(len(karte)):
        if sifra_s in karte[i].sifra_sale:
            lista.append(i)
    return lista

def pronadji_projekcije_sale(sifra_s):
    projekcije=citanje_bioskopske_projekcije()
    lista=[]
    for i in projekcije:
        if sifra_s in i.sala:
            lista.append(i.sifra)
    return lista

def pronadji_projekcije_film(film):
    projekcije=citanje_bioskopske_projekcije()
    lista=[]
    for i in projekcije:
        if film in i.film_prikazivanje:
            lista.append(i.sifra)
    return lista

