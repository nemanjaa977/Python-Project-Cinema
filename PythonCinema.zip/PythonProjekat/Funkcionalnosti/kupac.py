from _ast import Load
from os import terminal_size

from Ucitavanje.citanje_iz_fajla import citanje_termina_projekcije
from Funkcionalnosti.sala_termin import prikaz_termina
from Ucitavanje.citanje_iz_fajla import citanje_sala_projekcije,citanje_rezervacije_karte, citanje_bioskopske_projekcije,citanje_bioskopske_karte
from Model.Klase import Rezervacija, BioskopskaKarta
from Ucitavanje.pisanje_u_fajl import upis_rezervacije_karte, upis_bioskopske_karte
from Funkcionalnosti.dodatno import prikaz_menija, provera_unosa
from Aplikacija import Login
import random
import time
from datetime import datetime


def pronadji_salu(sifra):
    lista_sala=citanje_sala_projekcije()
    for x in lista_sala:
        if x.sifra_sale == sifra:
            return x

def rezervacija_za_ispis(zauzeto,red,oznaka):
    za_zamenu=[]
    izmenjena_oznaka=list(oznaka)
    ispis = str(red) + "- "
    for x in zauzeto:
        if red == int(x["red"]):
            za_zamenu.append(x["sediste"])
    if len(za_zamenu)==0:
        for o in izmenjena_oznaka:
            ispis+=o+" "
            #ako nije bilo izmene sedista
    else:
        lista=[]
        for s in oznaka:
            if za_zamenu.__contains__(s):
                lista.append(oznaka.index(s))
        for index in lista:
            izmenjena_oznaka[index]="X"
        ispis+=" ".join(izmenjena_oznaka)

    return ispis

def pronadji_rezervisana_sedista(sala):
    zauzeto=[]
    rezervacije=citanje_rezervacije_karte()
    for x in rezervacije:
        d = {}
        if x.sifra_sale==sala.sifra_sale:
            d["red"]=x.red_sedista
            d["sediste"]=x.oznaka_sedista
            zauzeto.append(d)
    lista_zauzetih = sorted(zauzeto,key=lambda k: k["red"])
    return lista_zauzetih

def rezervacija_karte():

    redni_broj = random.randint(0, 150)

    te = citanje_termina_projekcije()
    prikaz_termina(te)
    print("")
    list=[]
    uneto = input("Izaberite sifru termina: ")
    for m in te:
        list.append(m.sifra_termina)
    while list.__contains__(uneto) == False:
        print("Uneta sifra nepostoji!")
        uneto = input("Izaberite sifru termina: ")

    lista_sala=citanje_sala_projekcije()
    print("")
    print("|{:^10s}|{:^10s}|{:^10s}|".format("Sifra sale", "Naziv sale", "Broj redova"))
    for x in lista_sala:
        print("|{:^10s}|{:^10s}|{:^10d}|".format(x.sifra_sale,x.naziv_sale,x.broj_redova))
    print("")
    sifra_s=input("Unesite sifru sale: ")
    listt=[]
    for n in lista_sala:
        listt.append(n.sifra_sale)
    while listt.__contains__(sifra_s) == False:
        print("Izabrana sala ne postoji!")
        sifra_s = input("Unesite sifru sale: ")
    sala=pronadji_salu(sifra_s)
    zauzeto=pronadji_rezervisana_sedista(sala)
    ispis=""
    oznaka_s = sala.oznaka_sedista
    for red in range(1,sala.broj_redova+1):
        ispis+=str(red)+"- "
        ispis=rezervacija_za_ispis(zauzeto,red,oznaka_s)
        print(ispis)
        ispis=""

    uneseni_red = int(input("Unesite broj reda koji zelite: "))
    while uneseni_red > sala.broj_redova:
        print("Uneti broj, prevazilazi broj redova koji iznosi ",sala.broj_redova)
        uneseni_red = int(input("Unesite broj reda koji zelite: "));

    sedista=['A','B','C','D','E']
    uneseno_sediste = input("Unesite oznaku sedista koje zelite: ").upper();
    while uneseno_sediste not in sedista or proveri_sediste(zauzeto,uneseno_sediste,uneseni_red) == False:
        print("Nemoguce uneti izabrane podatke!")
        uneseno_sediste = input("Unesite oznaku sedista koje zelite: ").upper();


    if Login.logovani.uloga == "Kupac":
        kupac = Login.logovani.korisnicko_ime
        prodavac = None
    else:
        kupac=input("Unesite korisnicko ime kupca: ")
        prodavac = Login.logovani.korisnicko_ime

    mm = Rezervacija(redni_broj, uneto, sifra_s, uneseni_red, uneseno_sediste, kupac)

    redni_broj = random.randint(0, 150)
    datum = time.strftime("%d.%m.%Y.")
    pk= BioskopskaKarta(redni_broj,Login.logovani.ime, Login.logovani.prezime,kupac,uneto,sifra_s,uneseni_red,uneseno_sediste,datum,"Rezervisana",prodavac)
    lista=citanje_bioskopske_karte()
    lista.append(pk)
    upis_bioskopske_karte(lista)

    return mm

def rezervacija_glavni():
    fi = citanje_rezervacije_karte()
    r = rezervacija_karte()
    fi.append(r)
    upis_rezervacije_karte(fi)
    print("Uspesno dodata rezervacija karte!! \n")

    print("Da li zelite da nastavite sa rezervacijom karata? ")
    while True:
        prikaz_menija("Izaberite opciju: ", "1 - Rezervacija karte", "2 - Izlaz")
        opcija = provera_unosa("Opcija:", "Opcija mora biti celobrojna vrednost", int)
        if opcija == 2:
            break
        elif opcija == 1:
            fi = citanje_rezervacije_karte()
            r = rezervacija_karte()
            fi.append(r)
            upis_rezervacije_karte(fi)

def prikaz_rezervacije(rez):
    zaglavlje = "|{:^17s}|{:^15s}|{:^15s}|{:^15s}|{:^20s}|{:^20s}|".format("Redni broj", "Sifra termina", "Sifra sale", "Broj reda", "Oznaka sedista", "Kupac")
    s = len(zaglavlje)
    print(zaglavlje)
    print("-"*s)
    for t in rez:
        if t.kupac == Login.logovani.korisnicko_ime:
            print("|{:^17s}|{:^15s}|{:^15s}|{:^15s}|{:^20s}|{:^20s}|".format(t.redni_broj, t.sifra_termina, t.sifra_sale, t.red_sedista, t.oznaka_sedista, t.kupac))

def pregled_rez_karata():

    rez = citanje_rezervacije_karte()
    zaglavlje = "|{:^15s}|{:^15s}|{:^15s}|{:^20s}|{:^20s}|{:^20s}|{:^20s}|".format("Sifra termina", "Broj reda",
                        "Oznaka sedista", "Naziv filma", "Datum odrzavanja", "Vreme pocetka", "Vreme kraja")
    s = len(zaglavlje)
    print(zaglavlje)
    print("-"*s)
    for t in rez:
        bioskopska_p = pronadji_bio_projekciju(t.sifra_termina[:4])
        termin_p=pronadji_termin(t.sifra_termina)
        if t.kupac == Login.logovani.korisnicko_ime:
            print("|{:^15s}|{:^15s}|{:^15s}|{:^20s}|{:^20s}|{:^20s}|{:^20s}|".format(t.sifra_termina, t.red_sedista, t.oznaka_sedista,
                bioskopska_p.film_prikazivanje, termin_p.datum_odrzavanja, bioskopska_p.vreme_pocetka, bioskopska_p.vreme_kraja))


def pronadji_termin(termin_s):
    termini=citanje_termina_projekcije()
    for x in termini:
        if termin_s in x.sifra_termina:
            return x



def pronadji_bio_projekciju(termin_s):
    projekcije=citanje_bioskopske_projekcije()
    for x in projekcije:
        if  x.sifra in termin_s:
            return x


def ponistavanje_rezervacije():
    rezer = citanje_rezervacije_karte()
    prikaz_rezervacije(rezer)
    print("")
    uneto = input("Unesite redni broj rezervacije koju zelite da ponistite: ")
    mmm=[]
    for j in rezer:
        mmm.append(j.redni_broj)
    while mmm.__contains__(uneto) == False:
        print("Izabrana projekcija ne postoji, pokusajte ponovo!")
        uneto = input("Unesite redni broj rezervacije koju zelite da ponistite: ")
    for i in range(len(rezer)):
        if uneto == rezer[i].redni_broj:
            index=i
    rezer.pop(index)
    upis_rezervacije_karte(rezer)

def ponistavanje_rez_glavni():
    ponistavanje_rezervacije()

    print("Uspesno ponistena rezervacija karte!! \n")

    print("Da li zelite da nastavite sa ponistavanjem rezrvacije karata? ")
    while True:
        prikaz_menija("Izaberite opciju: ", "1 - Ponistavanje rezervacije", "2 - Izlaz")
        opcija = provera_unosa("Opcija:", "Opcija mora biti celobrojna vrednost", int)
        if opcija == 2:
            break
        elif opcija == 1:
            ponistavanje_rezervacije()


def proveri_sediste(zauzeto,uneto_s,uneti_r):

    for x in zauzeto:
        if uneti_r==int(x["red"]) and uneto_s == x["sediste"]:
            return False

    return True