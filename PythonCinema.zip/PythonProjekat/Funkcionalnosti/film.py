from Ucitavanje.citanje_iz_fajla import citanje_filmova
from Funkcionalnosti.dodatno import prikaz_menija, provera_unosa, vrednost_za_pretragu


def prikaz_filmova(filmovi):
    zaglavlje = "|{:^20s}|{:^15s}|{:^15s}|{:^15s}|{:^80s}|{:^15s}|{:^15s}|".format("Naziv", "Zanr", "Trajanje(min)",
                                                        "Reziseri", "Glavne uloge", "Zemlja porekla", "Godina proizvodnje")
    s = len(zaglavlje)
    print(zaglavlje)
    print("-"*s)
    ispis=""
    for f in filmovi:
        print("|{:^20s}|{:^15s}|{:^15d}|{:^15s}|".format(f.naziv, f.zanr, f.trajanje, f.reziser), end="")
        duzina_uloge=0
        for i in f.glavne_uloge:
            duzina_uloge+=len(i)+1
            ispis+=i+","
        if duzina_uloge<80:
            popuniti=" "*(80-duzina_uloge)
            print(ispis+popuniti, end="")
        print("|{:^15s}|{:^18d}|".format(f.zemlja_porekla, f.godina_proizvodnje))
        ispis=""

def pretraga_filmova():
    while True:
        prikaz_menija("Pretraga filmova:","1 - po nazivu","2 - po zanru","3 - po trajanju","4 - po reziserima",
                      "5 - po glavnim ulogama","6 - po zemlji porekla", "7 - po godini proizvodnje","8 - Izlaz")
        opcija=provera_unosa("Opcija:","Opcija mora biti celobrojna vrednost",int)
        if opcija==8:
            break
        elif opcija==1:
            naziv=input("Unesite naziv za pretragu: ")
            pronadjeni = pretraga_po_nazivu(naziv)
            prikaz_filmova(pronadjeni)
        elif opcija==2:
            zanr=input("Unesite zanr za pretragu: ")
            pronadjeni = pretraga_po_zanru(zanr)
            prikaz_filmova(pronadjeni)
        elif opcija==3:
            minimalna=vrednost_za_pretragu("Unesite minimalnu vrednost trajanja filma za pretragu:",int)
            maksimalna=vrednost_za_pretragu("Unesite maksimalnu vrednost trajanja filma za pretragu:",int)
            pronadjeni=pretraga_po_trajanju(minimalna, maksimalna)
            prikaz_filmova(pronadjeni)
        elif opcija==4:
            rez = input("Unesite rezisera za pretragu: ")
            pronadjeni = pretraga_po_reziserima(rez)
            prikaz_filmova(pronadjeni)
        elif opcija==5:
            uloge = input("Unesite ulogu za pretragu: ")
            pronadjeni = pretraga_po_glavinm_ulogama(uloge)
            prikaz_filmova(pronadjeni)
        elif opcija==6:
            zemlja=input("Unesite zemlju porekla za pretragu: ")
            pronadjeni = pretraga_po_zemlji_porekla(zemlja)
            prikaz_filmova(pronadjeni)
        elif opcija==7:
            godina=input("Unesite godinu proizvodnje za pretragu: ")
            pronadjeni = pretraga_po_godini_proizvodenje(godina)
            prikaz_filmova(pronadjeni)

def pretraga_po_nazivu(naziv):
    pronadjeni=[]
    filmovi=citanje_filmova()
    for f in filmovi:
        if naziv.lower() in f.naziv.lower():
            pronadjeni.append(f)
    return pronadjeni

def pretraga_po_zanru(zanr):
    pronadjeni=[]
    filmovi=citanje_filmova()
    for f in filmovi:
        if zanr.lower() in f.zanr.lower():
            pronadjeni.append(f)
    return pronadjeni

def pretraga_po_zemlji_porekla(zemlja_porekla):
    pronadjeni=[]
    filmovi=citanje_filmova()
    for f in filmovi:
        if zemlja_porekla.lower() in f.zemlja_porekla.lower():
            pronadjeni.append(f)
    return pronadjeni

def pretraga_po_godini_proizvodenje(godina_proizvodnje):
    pronadjeni=[]
    filmovi=citanje_filmova()
    for f in filmovi:
        if godina_proizvodnje in str(f.godina_proizvodnje):
            pronadjeni.append(f)
    return pronadjeni

def pretraga_po_trajanju(minimalna, maksimalna):
    pronadjeni = []
    filmovi = citanje_filmova()
    for f in filmovi:
        if minimalna is not None:
            if f.trajanje < minimalna:
                continue
        if maksimalna is not None:
            if f.trajanje > maksimalna:
                continue

        pronadjeni.append(f)
    return pronadjeni

def pretraga_po_glavinm_ulogama(glavne_uloge):
    pronadjeni=[]
    filmovi=citanje_filmova()
    for f in filmovi:
        for uloga in f.glavne_uloge:
            if glavne_uloge.lower() in uloga.lower():
               pronadjeni.append(f)
    return pronadjeni

def pretraga_po_reziserima(reziser):
    pronadjeni=[]
    filmovi=citanje_filmova()
    for f in filmovi:
        if reziser.lower() in f.reziser.lower():
               pronadjeni.append(f)
    return pronadjeni