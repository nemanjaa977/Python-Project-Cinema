from Model.Klase import Film, BioskopskaProjekcija, SalaProjekcije, TerminProjekcije
from Funkcionalnosti.dodatno import prikaz_menija, provera_unosa
from Ucitavanje.citanje_iz_fajla import citanje_filmova, citanje_bioskopske_projekcije, citanje_sala_projekcije, citanje_termina_projekcije
from Ucitavanje.pisanje_u_fajl import upis_filmova, upis_projekcija, upis_sale, upis_termina
from Funkcionalnosti.film import prikaz_filmova
from Funkcionalnosti.sala_termin import prikaz_sala
from Funkcionalnosti.b_projekcija import prikaz_projekcija
from datetime import datetime
import re
def meni_dodavanje():
    while True:
        prikaz_menija("Izaberite opciju: ", "1 - Unos bioskopske projekcije", "2 - Unos sale za projekciju",
                      "3 - Unos filma", "4 - Unos termina projekcije","5 - Izlaz")
        opcija = provera_unosa("Opcija:", "Opcija mora biti celobrojna vrednost", int)
        if opcija == 5:
            break
        elif opcija == 1:
            bi = citanje_bioskopske_projekcije()
            e = dodavanje_bioskopske_projekcije()
            bi.append(e)
            upis_projekcija(bi)
            print("Projekcija uspesno dodata! \n{}".format(e))
        elif opcija == 2:
            si = citanje_sala_projekcije()
            o = dodavanje_sale()
            si.append(o)
            upis_sale(si)
            print("Sala uspesno dodata! \n{}".format(o))
        elif opcija == 3:
            fi=citanje_filmova()
            r=dodavanje_filma()
            fi.append(r)
            upis_filmova(fi)
            print("Film uspesno dodat! \n{}".format(r))
        elif opcija == 4:
            ti = citanje_termina_projekcije()
            tt = dodavanje_termina_projekcije()
            ti.append(tt)
            upis_termina(ti)
            print("Termin uspesno dodat! \n{}".format(tt))

def dodavanje_bioskopske_projekcije():
    print("Unos podataka za novu bioskopsku projekciju: ")
    sifra = input("Sifra: ")
    while len(sifra) > 4:
        print("Sifra se mora sastojati od 4 karaktera!")
        sifra = input("Sifra: ")
    kom = []
    m = citanje_bioskopske_projekcije()
    for c in m:
        kom.append(c.sifra)
    while kom.__contains__(sifra) == True:
        print("Izabrana sufra vec postiji! Unesite novu")
        sifra = input("Sifra: ")

    sal = citanje_sala_projekcije()
    prikaz_sala(sal)
    sala = input("Sifra sale: ")
    list=[]
    for j in sal:
        list.append(j.sifra_sale)
    while list.__contains__(sala) == False:
        print("Izabrana sala ne postoji!")
        sala = input("Sifra sale: ")

    vreme_pocetka = input("Vreme pocetka: ")
    while format_vremena(vreme_pocetka) == False:
        print("Vreme mora biti u formatu HH:mm !")
        vreme_pocetka = input("Vreme pocetka: ")
    vreme_kraja = input("Vreme kraja: ")
    while format_vremena(vreme_kraja) == False:
        print("Vreme mora biti u formatu HH:mm !")
        vreme_kraja = input("Vreme kraja: ")

    jos_dana = True
    danii = ["Ponedeljak", "Utorak", "Sreda", "Cetvrtak", "Petak", "Subota", "Nedelja"]
    dani_odrzavanja = []
    while jos_dana == True:
        dan = input("Dan u nedelji: ")
        while dan.capitalize() not in danii:
            print("Izabrali ste ne postojeci dan u nedelji!")
            dan = input("Dan u nedelji: ")
        dani_odrzavanja.append(dan)
        ima_jos_str = input("Da li ima jos [y/n]?")
        if ima_jos_str == 'n':
            break


    filmovi = citanje_filmova()
    prikaz_filmova(filmovi)
    film_prikazivanje = input("Naziv filma: ")
    list=[]
    for d in filmovi:
        list.append(d.naziv);
    while list.__contains__(film_prikazivanje) == False:
        print("Izabrani film ne postoji na repertoaru!")
        film_prikazivanje = input("Naziv filma: ")

    try:
        cena_karte = float(input("Cena karte: "))
    except ValueError:
        print("Uneti samo BROJ! Pokusajte ponovo!")
        cena_karte = float(input("Cena karte: "))

    b = BioskopskaProjekcija(sifra, sala, vreme_pocetka, vreme_kraja, dani_odrzavanja, film_prikazivanje, cena_karte)
    return b

def dodavanje_sale():
    print("Unos podataka za novu salu: ")
    sifra_sale = input("Sifra: ")
    while len(sifra_sale) > 2:
        print("Sifra se mora sastojati od 2 karaktera!")
        sifra_sale = input("Sifra: ")
    komm = []
    sa = citanje_sala_projekcije()
    for c in sa:
        komm.append(c.sifra_sale)
    while komm.__contains__(sifra_sale) == True:
        print("Izabrana sufra vec postiji! Unesite novu")
        sifra_sale = input("Sifra: ")

    naziv_sale = input("Naziv: ")

    try:
        broj_redova = int(input("Broj redova: "))
        while broj_redova > 10:
            print("Sala ima maksimum 10 redova!")
            broj_redova = int(input("Broj redova: "))
    except ValueError:
        print("Sala ima maksimum 10 redova!")
        broj_redova = int(input("Broj redova: "))

    broj_sedista_u_redu = 5
    sedista=['A','B','C','D','E']

    s = SalaProjekcije(sifra_sale, naziv_sale, broj_redova, sedista)
    return s

def dodavanje_filma():
    print("Unos podataka za novi film: ")
    naziv=input("Naziv: ")
    zanr = input("Zanr: ")

    try:
        trajanje=int(input("Trajanje: "))
    except ValueError:
        print("Trajanje mora biti ceo broj! (Izrazeno u minutima)")
        trajanje = int(input("Trajanje: "))

    reziser = input("Reziser: ")

    ima_jos = True
    glavne_uloge = []
    while ima_jos == True:
        glavna_uloga=input("Glavna uloga: ")
        glavne_uloge.append(glavna_uloga)
        ima_jos_str = input("Da li ima jos [y/n]?")
        if ima_jos_str == 'n':
            break
    zemlja_porekla = input("Zemlja porekla: ")

    try:
        godina_proizvodnje=int(input("Godina proizvodnje: "))
        while godina_proizvodnje > 2018:
            print("Izabrana godina jos nije pocela. Nemoguce izabrati!")
            godina_proizvodnje = int(input("Godina proizvodnje: "))
    except ValueError:
        print("Godina mora biti ceo broj! (int)")
        godina_proizvodnje = int(input("Godina proizvodnje: "))

    skraceni_opis_filma = input("Skraceni opis filma: ")

    f = Film(naziv, zanr, trajanje, reziser, glavne_uloge, zemlja_porekla, godina_proizvodnje, skraceni_opis_filma)
    return f

def dodavanje_termina_projekcije():
    print("Unos podataka za novi termin projekcije: ")
    bio = citanje_bioskopske_projekcije()
    prikaz_projekcija(bio)
    print("")
    bio_projekcija = input("Sifra bioskopske projekcije: ")
    list=[]
    for d in bio:
        list.append(d.sifra);
    while list.__contains__(bio_projekcija) == False:
        print("Ne postoji nijedna projekcija sa izabranom sifrom! Pokusajte ponovo!")
        bio_projekcija = input("Sifra bioskopske projekcije: ")

    s_termina = input("Sifra termina: ")
    while len(s_termina) > 2:
        print("Sifra termina ne moze imati vise od dva karaktera!")
        s_termina = input("Sifra termina: ")

    sifra_termina = bio_projekcija + s_termina

    try:
        datum_odrzavanja = input("Unesite datum odrzavanja(dd.mm.yyyy.): ")
        datum_neparsiran=p_datum(datum_odrzavanja)
        datum_parsiran = datetime.__format__(datum_neparsiran, "%d.%m.%Y.")
    except ValueError:
       try:
            print("Datum mora biti formata dd.mm.YYYY.")
            datum_odrzavanja = input("Unesite datum odrzavanja(dd.mm.yyyy.): ")   #datum moze dva puta greska, ispraviti
            datum_neparsiran=p_datum(datum_odrzavanja)
            datum_parsiran=datetime.__format__(datum_neparsiran,"%d.%m.%Y.")
       except ValueError:
           print("\nZao nam je ,zbog prevelikog broja gresaka morate sve iz pocetka\n")
           dodavanje_termina_projekcije()

    t = TerminProjekcije(sifra_termina, datum_parsiran)
    return t

def p_datum(datum):
    """
    Funkcija koja parsira datum, iz stringa u tip date.
    """
    return datetime.strptime(datum,"%d.%m.%Y.")



def format_vremena(s):
    time_re = re.compile(r'^(([01]\d|2[0-3]):([0-5]\d)|24:00)$')
    return bool(time_re.match(s))