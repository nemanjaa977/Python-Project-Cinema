from Funkcionalnosti.Unos import p_datum
from Ucitavanje.citanje_iz_fajla import citanje_bioskopske_karte, citanje_termina_projekcije, citanje_bioskopske_projekcije, citanje_korisnika
from Funkcionalnosti.dodatno import prikaz_menija, provera_unosa
from Funkcionalnosti.kupac import pronadji_bio_projekciju, pronadji_termin
import  time

def izvestaj():
    while True:
        prikaz_menija("Izaberite opciju: ", "(1) Lista prodatih karata za odabran datum prodaje",
                      "(2) Lista prodatih karata za odabran datum početka termina projekcije",
                      "(3) Lista prodatih karata za odabran datum prodaje i odabranog prodavca",
                      "(4) Ukupan broj i ukupna cena prodatih karata za izabran dan prodaje",
                      "(5) Ukupan broj i ukupna cena prodatih karata za izabran dan održavanja projekcije",
                      "(6) Ukupna cena prodatih karata za zadati film u svim projekcijama",
                      "(7) Ukupan broj i ukupna cena prodatih karata za izabran dan prodaje i odabranog prodavca",
                      "(8) Ukupan broj i ukupna cena prodatih karata po prodavcima (za svakog prodavca) u poslednjih 30 dana",
                      "(9) Izlaz")
        opcija = provera_unosa("Opcija:", "Opcija mora biti celobrojna vrednost", int)
        if opcija == 9:
            break
        elif opcija == 1:
            prodaja_za_odredjeni_datum()
        elif opcija == 2:
            datum_pocetka_termina()
        elif opcija == 3:
            prodaja_za_odabranog_prodavca()
        elif opcija == 4:
            cena_karte_za_izabran_dan()
        elif opcija == 5:
            cena_karte_za_izabran_dan_odrzavanja()
        elif opcija == 6:
            prodate_karte_za_naziv_filma()
        elif opcija == 7:
            izabran_dan_prodaje_i_prodavac()
        elif opcija == 8:
            poslednjih_30_dana()

def prodaja_za_odredjeni_datum():
    try:
        odabran_datum = input("Unesite datum prodaje(dd.mm.yy.): ")
        zaglavlje = "|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|".format("Redni broj", "Ime", "Prezime",
                                                                               "Sifra termina", "Red sedista",
                                                                               "Oznaka sedista", "Nacin")
        f = len(zaglavlje)
        print("-" * f)
        print(zaglavlje)
        print("-" * f)
        karte = citanje_bioskopske_karte()
        for karta in karte:
            if p_datum(karta.datum_prodaje) == p_datum(odabran_datum) and karta.rezervisano_kupljeno == "Prodata":
                print("|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|".format(karta.redni_broj, karta.ime, karta.prezime,
                                                                                 karta.termin_projekcije, karta.red_sedista,
                                                                                 karta.oznaka_sedista,
                                                                                 karta.rezervisano_kupljeno))
                print("-" * f)
    except ValueError:
        print("Datum mora biti formata dd.mm.YY.")

def datum_pocetka_termina():
    try:
        odabran_datum = input("Unesite datum odrzavanja termina (dd.mm.yy.): ")
        zaglavlje = "|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|".format("Redni broj", "Ime", "Prezime",
                                                                                       "Sifra termina", "Red sedista",
                                                                                       "Oznaka sedista", "Nacin")
        f = len(zaglavlje)
        print("-" * f)
        print(zaglavlje)
        print("-" * f)
        pronadjeni=[]
        termini = citanje_termina_projekcije()
        for g in termini:
            if p_datum(g.datum_odrzavanja) == p_datum(odabran_datum):
                pronadjeni.append(g.sifra_termina)
        karte=citanje_bioskopske_karte()

        karte_ispis=[]
        for karta in karte:
            if karta.rezervisano_kupljeno == "Prodata":
                if pronadjeni.__contains__(karta.termin_projekcije):
                    karte_ispis.append(karta)

        for k in karte_ispis:
            print("|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|".format(k.redni_broj, k.ime,
                                                                                         k.prezime,
                                                                                         k.termin_projekcije,
                                                                                         k.red_sedista,
                                                                                         k.oznaka_sedista,
                                                                                         k.rezervisano_kupljeno))
            print("-" * f)
    except ValueError:
        print("Datum mora biti formata dd.mm.YY.")

def prodaja_za_odabranog_prodavca():
    try:
        odabran_datum = input("Unesite datum prodaje(dd.mm.yy.): ")
        odabran_prodavac = input("Unesite korisniko ime prodavca: ")
        zaglavlje = "|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|".format("Redni broj", "Ime", "Prezime",
                                                                               "Sifra termina", "Red sedista",
                                                                               "Oznaka sedista", "Nacin", "Prodavac")
        f = len(zaglavlje)
        print("-" * f)
        print(zaglavlje)
        print("-" * f)
        karte = citanje_bioskopske_karte()
        o = "Prodata"
        for karta in karte:
            if p_datum(karta.datum_prodaje) == p_datum(odabran_datum) and odabran_prodavac in karta.prodavac and o == karta.rezervisano_kupljeno:
                print("|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|".format(karta.redni_broj, karta.ime, karta.prezime,
                                                                                 karta.termin_projekcije, karta.red_sedista,
                                                                                 karta.oznaka_sedista,
                                                                                 karta.rezervisano_kupljeno, karta.prodavac))
                print("-" * f)
    except ValueError:
        print("Datum mora biti formata dd.mm.YY.")

def cena_karte_za_izabran_dan():
    odabran_dan = input("Unesite dan za prikaz ukupnog broja karti i cene: ")
    zaglavlje = "|{:^15s}|{:^15s}|".format("Ukupan broj", "Ukupna cena")
    f = len(zaglavlje)
    print("-" * f)
    print(zaglavlje)
    print("-" * f)
    lista_karti = citanje_bioskopske_karte()
    broj=pronadji_broj_dana(odabran_dan)

    pronadjeni=[]
    for n in lista_karti:
        if n.rezervisano_kupljeno == "Prodata":
            datum=p_datum(n.datum_prodaje)
            if datum.weekday() == broj:
                #weekday odredjuje koji je dan bio tog datuma, vraca broj od 0 do 6
                pronadjeni.append(n)
    broj_karata=pronadjeni.__len__()
    ukupna_cena=0
    for x in pronadjeni:
        projekcija=pronadji_bio_projekciju(x.termin_projekcije[:4])
        ukupna_cena+=projekcija.cena_karte

    print("|{:^15d}|{:^15.2f}|".format(broj_karata, ukupna_cena))
    print("-" * f)

def pronadji_broj_dana(odabran_dan):
    if odabran_dan.upper() in "PONEDELJAK":
        broj_dana=0
    elif odabran_dan.upper() in "UTORAK":
        broj_dana=1
    elif odabran_dan.upper() in "SREDA":
        broj_dana = 2
    elif odabran_dan.upper() in "CETVRTAK":
        broj_dana = 3
    elif odabran_dan.upper() in "PETAK":
        broj_dana = 4
    elif odabran_dan.upper() in "SUBOTA":
        broj_dana = 5
    elif odabran_dan.upper() in "NEDELJA":
        broj_dana = 6
    return  broj_dana

def cena_karte_za_izabran_dan_odrzavanja():
    odabran_dan = input("Unesite dan odrzavanja projekcije: ")
    zaglavlje = "|{:^15s}|{:^15s}|".format("Ukupan broj", "Ukupna cena")
    f = len(zaglavlje)
    print("-" * f)
    print(zaglavlje)
    print("-" * f)
    projekcije = citanje_bioskopske_projekcije()

    pronadjeni=[]
    sifre_projekcije=[]
    for n in projekcije:
        dani=[]
        for x in n.dani_odrzavanja:
            dani.append(x)
        if dani.__contains__(odabran_dan)== True:
            pronadjeni.append(n)
            sifre_projekcije.append(n.sifra)
    karte=citanje_bioskopske_karte()
    prodate_karte=[]
    for k in karte:
        if k.rezervisano_kupljeno == "Prodata" and sifre_projekcije.__contains__(k.termin_projekcije[:4]):
            prodate_karte.append(k)

    broj_karata=prodate_karte.__len__()
    ukupna_cena=0
    for x in prodate_karte:
        p=pronadji_bio_projekciju(x.termin_projekcije[:4])
        ukupna_cena+=p.cena_karte

    print("|{:^15d}|{:^15.2f}|".format(broj_karata, ukupna_cena))
    print("-" * f)

def prodate_karte_za_naziv_filma():
    izabran_film = input("Naziv filma: ")
    zaglavlje = "|{:^15s}|".format("Ukupna cena")
    f = len(zaglavlje)
    print("-" * f)
    print(zaglavlje)
    print("-" * f)

    karte=citanje_bioskopske_karte()
    ukupna_cena=0
    prodate=[]
    for x in karte:
        if x.rezervisano_kupljeno == "Prodata":
            prodate.append(x)

    projekcije_za_prodate=[]

    for p in prodate:
        p=pronadji_bio_projekciju(p.termin_projekcije[:4])
        if p.film_prikazivanje == izabran_film:
            projekcije_za_prodate.append(p)

    for c in projekcije_za_prodate:
        ukupna_cena+=c.cena_karte
    print("|{:^15.2f}|".format(ukupna_cena))
    print("-" * f)


def izabran_dan_prodaje_i_prodavac():
    odabran_dan = input("Unesite dan prodaje: ")
    izabran_prodavac = input("Unesite korisnicko ime prodavca: ")
    zaglavlje = "|{:^15s}|{:^15s}|".format("Ukupan broj", "Ukupna cena")
    f = len(zaglavlje)
    print("-" * f)
    print(zaglavlje)
    print("-" * f)
    lista_karti = citanje_bioskopske_karte()
    broj=pronadji_broj_dana(odabran_dan)

    pronadjeni=[]
    for n in lista_karti:
        datum=p_datum(n.datum_prodaje)
        if datum.weekday() == broj and n.prodavac in izabran_prodavac and n.rezervisano_kupljeno == "Prodata":
            pronadjeni.append(n)
    broj_karata=pronadjeni.__len__()
    ukupna_cena=0
    for x in pronadjeni:
        projekcija=pronadji_bio_projekciju(x.termin_projekcije[:4])
        ukupna_cena+=projekcija.cena_karte

    print("|{:^15d}|{:^15.2f}|".format(broj_karata, ukupna_cena))
    print("-" * f)

def poslednjih_30_dana():
    karte =citanje_bioskopske_karte()
    korisnici=citanje_korisnika()
    prodavci=[]
    k_ime=[]
    for x in korisnici:
        if x.uloga == "Prodavac":
            prodavci.append(x)
            k_ime.append(x.korisnicko_ime)

    datum = time.strftime("%d.%m.%Y.")
    karte_30_dana=[]
    for k in karte:
        #pretvorim trenutni datum, i datum iz karte
        delta= p_datum(datum) - p_datum(k.datum_prodaje)
        if delta.days == 30:
            karte_30_dana.append(k)
    lista=[]
    for x  in k_ime:
        recnik={}
        lista_karti=[]
        recnik["prodavac"]=x
        for s in karte_30_dana:
            if x == s.prodavac:
                lista_karti.append(s)
        recnik["karte"]=lista_karti
        lista.append(recnik)

    zaglavlje = "|{:^10s}|{:^15s}|{:^15s}|".format("Prodavac","Ukupan broj", "Ukupna cena")
    f = len(zaglavlje)
    print("-" * f)
    print(zaglavlje)
    print("-" * f)

    for x in lista:
        print("|{:^10s}|{:^15d}|{:^15.2f}|".format(x["prodavac"], x["karte"].__len__(),racunanje_ukupne_cene(x["karte"])))
        print("-" * f)


def racunanje_ukupne_cene(lista):
    ukupna_cena = 0
    for x in lista:
        projekcija = pronadji_bio_projekciju(x.termin_projekcije[:4])
        ukupna_cena += projekcija.cena_karte
    return ukupna_cena