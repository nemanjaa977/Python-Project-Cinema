def prikaz_menija(*meni_opcije):
    for i in range(3):
        print()
    for i in meni_opcije:
        print(i)

def provera_unosa(poruka,poruka_greska,convert):
    while True:
        try:
            return convert(input(poruka))
        except:
            print(poruka_greska)

def vrednost_za_pretragu(poruka,convert):
    try:
        return convert(input(poruka))
    except:
        return None