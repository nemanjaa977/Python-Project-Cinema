from Funkcionalnosti.dodatno import prikaz_menija, provera_unosa
from Ucitavanje.citanje_iz_fajla import citanje_termina_projekcije, citanje_sala_projekcije, citanje_rezervacije_karte,\
citanje_bioskopske_karte, citanje_bioskopske_projekcije, citanje_korisnika
from Funkcionalnosti.sala_termin import prikaz_termina
from Ucitavanje.pisanje_u_fajl import upis_bioskopske_karte
from Model.Klase import BioskopskaKarta
from datetime import datetime
import random
import time
from Aplikacija import Login
from Funkcionalnosti.kupac import proveri_sediste

def glavni_meni_prodavacaaa():
    while True:
        prikaz_menija("Izaberite opciju: ", "1 - Direktna prodaja", "2 - Prodaja rezervisanih karata", "3 - Izlaz")
        opcija = provera_unosa("Opcija:", "Opcija mora biti celobrojna vrednost", int)
        if opcija == 3:
            break
        elif opcija == 1:
            prodaja_karata_glavni()
        elif opcija == 2:
            prodaja_rezervisanih_karata()

def prodaja_karte():
    redni_broj = random.randint(0, 150)
    ime = input("Unesite ime: ")

    prezime = input("Unesite prezime: ")

    te = citanje_termina_projekcije()
    prikaz_termina(te)
    print("")
    uneto = input("Izaberite sifru termina: ")
    ll=[]
    for t in te:
        ll.append(t.sifra_termina)
    while ll.__contains__(uneto) == False:
        print("Uneta sifra nepostoji!")
        uneto = input("Izaberite sifru termina: ")

    lista_sala=citanje_sala_projekcije()
    print("")
    print("|{:^10s}|{:^10s}|{:^10s}|".format("Sifra sale", "Naziv sale", "Broj redova"))
    for x in lista_sala:
        print("|{:^10s}|{:^10s}|{:^10d}|".format(x.sifra_sale,x.naziv_sale,x.broj_redova))
    print("")
    sifra_s=input("Unesite sifru sale: ")
    listt = []
    for n in lista_sala:
        listt.append(n.sifra_sale)
    while listt.__contains__(sifra_s) == False:
        print("Izabrana sala ne postoji!")
        sifra_s = input("Unesite sifru sale: ")
    sala=pronadji_salu(sifra_s)
    zauzeto=pronadji_rezervisana_sedista(sala)
    ispis=""
    oznaka_s = sala.oznaka_sedista
    for red in range(1,sala.broj_redova+1):
        ispis+=str(red)+"- "
        ispis=rezervacija_za_ispis(zauzeto,red,oznaka_s)
        print(ispis)
        ispis=""
    uneseni_red = int(input("Unesite broj reda koji zelite: "));
    while uneseni_red > sala.broj_redova:
        print("Uneti broj, prevazilazi broj redova koji iznosi ",sala.broj_redova)
        uneseni_red = int(input("Unesite broj reda koji zelite: "));

    sedista=['A','B','C','D','E']
    uneseno_sediste = input("Unesite oznaku sedista koje zelite: ").upper();
    while uneseno_sediste not in sedista or proveri_sediste(zauzeto,uneseno_sediste,uneseni_red) == False:
        print("Nemoguce uneti izabrane podatke!")
        uneseno_sediste = input("Unesite oznaku sedista koje zelite: ").upper();

    kupac = input("Unesite korisnicko ime kupca: ")

    datum = time.strftime("%d.%m.%Y.")

    rezervisano_kupljeno = "Prodata"



    mm = BioskopskaKarta(redni_broj, ime, prezime, kupac, uneto, sifra_s, uneseni_red, uneseno_sediste, datum, rezervisano_kupljeno, Login.logovani.korisnicko_ime)
    return mm

def prodaja_karata_glavni():
    fi = citanje_bioskopske_karte()
    r = prodaja_karte()
    fi.append(r)
    upis_bioskopske_karte(fi)
    print("Uspesno prodata karta!! \n")

    print("Da li zelite da nastavite sa prodajom karata? ")
    while True:
        prikaz_menija("Izaberite opciju: ", "1 - Prodaja karte", "2 - Izlaz")
        opcija = provera_unosa("Opcija:", "Opcija mora biti celobrojna vrednost", int)
        if opcija == 2:
            break
        elif opcija == 1:
            fi = citanje_rezervacije_karte()
            r = prodaja_karte()
            fi.append(r)
            upis_bioskopske_karte(fi)

def pronadji_salu(sifra):
    lista_sala=citanje_sala_projekcije()
    for x in lista_sala:
        if x.sifra_sale == sifra:
            return x

def rezervacija_za_ispis(zauzeto,red,oznaka):
    za_zamenu=[]
    izmenjena_oznaka=list(oznaka)
    ispis = str(red) + "- "
    for x in zauzeto:
        if red == int(x["red"]):
            za_zamenu.append(x["sediste"])
    if len(za_zamenu)==0:
        for o in izmenjena_oznaka:
            ispis+=o+" "
    else:
        lista=[]
        for s in oznaka:
            if za_zamenu.__contains__(s):
                lista.append(oznaka.index(s))
        for index in lista:
            izmenjena_oznaka[index]="X"
        ispis+=" ".join(izmenjena_oznaka)

    return ispis

def pronadji_rezervisana_sedista(sala):
    zauzeto=[]
    rezervacije=citanje_rezervacije_karte()
    for x in rezervacije:
        d = {}
        if x.sifra_sale==sala.sifra_sale:
            d["red"]=x.red_sedista
            d["sediste"]=x.oznaka_sedista
            zauzeto.append(d)
    lista_zauzetih = sorted(zauzeto,key=lambda k: k["red"])
    return lista_zauzetih



def prodaja_rezervisanih_karata():
    karte = citanje_bioskopske_karte()
    zaglavlje = "|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|".format("Redni broj", "Ime", "Prezime", "Sifra termina", "Red sedista", "Oznaka sedista", "Nacin")
    s = len(zaglavlje)
    print(zaglavlje)
    print("-"*s)
    for l in karte:
        if l.rezervisano_kupljeno == "Rezervisana":
            print("|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|".format(l.redni_broj, l.ime, l.prezime, l.termin_projekcije, l.red_sedista,
                                                                             l.oznaka_sedista, l.rezervisano_kupljeno))
    uneto = input("Unesite redni broj karte: ")
    for b in karte:
        if uneto == b.redni_broj:
            b.rezervisano_kupljeno = "Prodata"
            b.prodavac = Login.logovani.korisnicko_ime

    upis_bioskopske_karte(karte)

def ponistavanje_rezervacije_prodaje():
    n = citanje_bioskopske_karte()

    zaglavlje = "|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|".format("Redni broj", "Ime", "Prezime", "Sifra termina",
                                                                           "Red sedista", "Oznaka sedista", "Korisnicko ime", "Nacin")
    s = len(zaglavlje)
    print(zaglavlje)
    print("-" * s)
    for l in n:
        print("|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|{:^15s}|".format(l.redni_broj, l.ime, l.prezime,
                                                                             l.termin_projekcije, l.red_sedista,
                                                                             l.oznaka_sedista, l.korisnicko_ime, l.rezervisano_kupljeno))
    print("")
    uneto = input("Unesite redni broj karte koju zelite da ponsitite: ")
    uRed=[]
    for j in n:
        uRed.append(j.redni_broj)
    while uRed.__contains__(uneto) == False:
        print("Izabrana projekcija ne postoji, pokusajte ponovo!")
        uneto = input("Unesite redni broj rezervacije koju zelite da ponistite: ")
    for i in range(len(n)):
        if uneto == n[i].redni_broj:
            index=i
    n.pop(index)
    upis_bioskopske_karte(n)

def ponistavanje_rez_prodate_glavni():
    ponistavanje_rezervacije_prodaje()

    print("Uspesno ponistena karta!! \n")

    print("Da li zelite da nastavite sa ponistavanjem rezervisane/prodate karte? ")
    while True:
        prikaz_menija("Izaberite opciju: ", "1 - Ponistavanje rezervisane/prodate karte ", "2 - Izlaz")
        opcija = provera_unosa("Opcija:", "Opcija mora biti celobrojna vrednost", int)
        if opcija == 2:
            break
        elif opcija == 1:
            ponistavanje_rezervacije_prodaje()

def pregled_rezervisanih_karata():
    rez = citanje_rezervacije_karte()
    zaglavlje = "|{:^15s}|{:^15s}|{:^15s}|{:^20s}|{:^20s}|{:^20s}|{:^20s}|{:^15s}|{:^15s}|".format("Sifra termina", "Korisnicko ime",
                        "Red sedista", "Oznaka sedista", "Naziv filma", "Datum odrzavanja", "Vreme pocetka", "Vreme kraja", "Ime", "Prezime")
    s = len(zaglavlje)
    print(zaglavlje)
    print("-" * s)
    for t in rez:
        bioskopska_p = pronadji_bio_projekciju(t.sifra_termina[:4])
        termin_p = pronadji_termin(t.sifra_termina)
        karte_p = pronadji_kartu_ime_prezime(t.sifra_termina)
        print("|{:^15s}|{:^15s}|{:^15s}|{:^20s}|{:^20s}|{:^20s}|{:^20s}|{:^15s}|{:^15s}|".format(t.sifra_termina, t.kupac,
                                                                                 t.red_sedista, t.oznaka_sedista,
                                                                                 bioskopska_p.film_prikazivanje,
                                                                                 termin_p.datum_odrzavanja,
                                                                                 bioskopska_p.vreme_pocetka,
                                                                                 bioskopska_p.vreme_kraja,
                                                                                 karte_p.ime, karte_p.prezime))

def pronadji_bio_projekciju(termin_s):
    projekcije=citanje_bioskopske_projekcije()
    for x in projekcije:
        if termin_s == x.sifra:
            return x

def pronadji_termin(termin_s):
    termini=citanje_termina_projekcije()
    for x in termini:
        if x.sifra_termina == termin_s:
            return x

def pronadji_kartu_ime_prezime(ime_s):
    karte=citanje_bioskopske_karte()
    for x in karte:
        if x.termin_projekcije == ime_s:
            return x

def pronadji_kartu_termin(termin_s):
    karte=citanje_bioskopske_karte()
    for x in karte:
        if termin_s in x.termin_projekcije:
            return x