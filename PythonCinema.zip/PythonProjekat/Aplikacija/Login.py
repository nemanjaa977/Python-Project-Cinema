from Ucitavanje.citanje_iz_fajla import citanje_korisnika
from Model.Klase import Osoba
from Ucitavanje.pisanje_u_fajl import upis_osoba

logovani=None
def login():
    global logovani
    korIme = input("\nUnesite korisnicko ime: ")
    lozinka = input("Unesite lozinku: ")
    korisnici = citanje_korisnika()
    for k in korisnici:
        if k.korisnicko_ime == korIme and k.lozinka == lozinka:
            print("\n<<<Uspesna prijava>>>\n")
            logovani=k
            return  True
    print("\nUneti korisnik ne postoji!!!\n")
    return False

def registracija_add():
    osobe = citanje_korisnika()
    korisnicko_ime = input("Korisnicko ime: ")
    for o in osobe:
        while korisnicko_ime == o.korisnicko_ime:
            print("Izabrano korisnicko ime vec postoji! Unesite drugo!")
            korisnicko_ime = input("Korisnicko ime: ")

    loznka = input("Lozinka:")
    while len(loznka) < 6:
        print("Lozinka mora imati najmanje 6 karaktera!")
        loznka = input("Lozinka:")

    ime = input("Ime: ")
    prezime = input("Prezime: ")
    uloga = "Kupac"

    ll = Osoba(korisnicko_ime, loznka, ime, prezime, uloga)
    return ll

def registracija():
    fi = citanje_korisnika()
    r = registracija_add()
    fi.append(r)
    upis_osoba(fi)
    print("Uspesna registracija! \n")

def registracija_menadzer_prodavac():
    osobe = citanje_korisnika()
    korisnicko_ime = input("Korisnicko ime: ")
    for o in osobe:
        while korisnicko_ime == o.korisnicko_ime:
            print("Izabrano korisnicko ime vec postoji! Unesite drugo!")
            korisnicko_ime = input("Korisnicko ime: ")

    loznka = input("Lozinka:")
    ime = input("Ime: ")
    prezime = input("Prezime: ")
    f = ['Prodavac', 'Menadzer']
    print("Moguc izbor korisnika: Prodavac/Menadzer")
    uloga = input("Uloga: ")
    while uloga not in f:
        print("Moguca je registracija prodavca i menadzera! Nista vise! Pocetno slovo veliko!")
        uloga = input("Uloga: ")

    ll = Osoba(korisnicko_ime, loznka, ime, prezime, uloga)
    return ll

def registracija_menadzer():
    fi = citanje_korisnika()
    r = registracija_menadzer_prodavac()
    fi.append(r)
    upis_osoba(fi)
    print("Uspesna registracija! \n")