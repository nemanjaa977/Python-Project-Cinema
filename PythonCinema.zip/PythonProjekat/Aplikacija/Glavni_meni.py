from Aplikacija.Login import registracija, login, registracija_menadzer
from Aplikacija import Login
from Funkcionalnosti.dodatno import prikaz_menija, provera_unosa
from Funkcionalnosti.film import prikaz_filmova, pretraga_filmova
from Funkcionalnosti.Unos import meni_dodavanje
from Funkcionalnosti.Izmena import meni_izmena
from Funkcionalnosti.Brisanje import meni_brisanje
from Ucitavanje.citanje_iz_fajla import citanje_filmova
from Funkcionalnosti.b_projekcija import pretraga_projekcija
from Funkcionalnosti.kupac import rezervacija_glavni, pregled_rez_karata, ponistavanje_rez_glavni
from Funkcionalnosti.prodavac import glavni_meni_prodavacaaa, ponistavanje_rez_prodate_glavni, pregled_rezervisanih_karata
from Funkcionalnosti.pretraga_karata import pretraga_karti
from Funkcionalnosti.izvestaji import izvestaj



def meni():
    print("Meni:\n ")
    print("1 - Prijava\n2 - Registracija\n3 - Izlazak iz aplikacije")
    opcija=input("Izaberite opciju: ")
    while opcija not in ("1","2","3"):
        print("\nUneli ste pogresu opciju.\n")
        opcija=input("Izaberite opciju: ")
    return opcija

def pocetak():
    try:
        print()
        print("Dobrodosli u aplikaciju Bioskop")
        print("-------------------------------")
        print()
        opcija = "0"
        while opcija != "X":
            opcija = meni()
            if opcija == "1":
                glavno()
            elif opcija == "2":
                registracija()
            elif opcija == "3":
                prekid()
        print("Dovidjenja")
    except Exception as e:
        print(e)

def glavno():
    if login()==True:
        if Login.logovani.uloga == "Kupac":
            glavni_meni_kupac()
        elif Login.logovani.uloga == "Prodavac":
            glavni_meni_prodavac()
        elif Login.logovani.uloga == "Menadzer":
            glavni_meni_menadzer()

def prekid():
    print("\nHvala na poseti, dovidjenja!\n")
    quit()

def glavni_meni_kupac():
    while True:
        prikaz_menija("Izaberite opciju: ", "1 - Prikaz filmova", "2 - Pretraga filmova","3 - Pretraga projekcija",
                      "4 - Rezervacija karata","5 - Pregled rezervisanih karata", "6 - Ponistavanje rezervacije karata", "7 - Odjava")
        opcija = provera_unosa("Opcija:", "Opcija mora biti celobrojna vrednost", int)
        if opcija == 7:
            pocetak()
        elif opcija == 1:
            filmovi = citanje_filmova()
            prikaz_filmova(filmovi)
        elif opcija == 2:
            pretraga_filmova()
        elif opcija == 3:
            pretraga_projekcija()
        elif opcija == 4:
            rezervacija_glavni()
        elif opcija == 5:
            pregled_rez_karata()
        elif opcija == 6:
            ponistavanje_rez_glavni()

def glavni_meni_prodavac():
    while True:
        prikaz_menija("Izaberite opciju: ", "1 - Prikaz filmova", "2 - Pretraga filmova","3 - Pretraga projekcija",
                      "4 - Rezervacija karata","5 - Pregled rezervisanih karata", "6 - Ponistavanje rezervisanih/prodatih karata",
                      "7 - Pretraga karata", "8 - Prodaja karata", "9 - Odjava", "10 - Izlazak iz aplikacije")
        opcija = provera_unosa("Opcija:", "Opcija mora biti celobrojna vrednost", int)
        if opcija == 9:
            pocetak()
        elif opcija == 1:
            filmovi = citanje_filmova()
            prikaz_filmova(filmovi)
        elif opcija == 2:
            pretraga_filmova()
        elif opcija == 3:
            pretraga_projekcija()
        elif opcija == 4:
            rezervacija_glavni()
        elif opcija == 5:
            pregled_rezervisanih_karata()
        elif opcija == 6:
            ponistavanje_rez_prodate_glavni()
        elif opcija == 7:
            pretraga_karti()
        elif opcija == 8:
            glavni_meni_prodavacaaa()
        elif opcija == 10:
            prekid()

def glavni_meni_menadzer():
    while True:
        prikaz_menija("Izaberite opciju: ", "1 - Prikaz filmova", "2 - Pretraga filmova","3 - Pretraga projekcija",
                      "4 - Dodavanje","5 - Izmena", "6 - Brisanje", "7 - Registracija", "8 - Izvestaji",
                      "9 - Odjava", "10 - Izlazak iz aplikacije")
        opcija = provera_unosa("Opcija:", "Opcija mora biti celobrojna vrednost", int)
        if opcija == 9:
            pocetak()
        elif opcija == 1:
            filmovi = citanje_filmova()
            prikaz_filmova(filmovi)
        elif opcija == 2:
            pretraga_filmova()
        elif opcija == 3:
            pretraga_projekcija()
        elif opcija == 4:
            meni_dodavanje()
        elif opcija == 5:
            meni_izmena()
        elif opcija == 6:
            meni_brisanje()
        elif opcija == 7:
            registracija_menadzer()
        elif opcija == 8:
            izvestaj()
        elif opcija == 10:
            prekid()

if __name__ == '__main__':
    pocetak()