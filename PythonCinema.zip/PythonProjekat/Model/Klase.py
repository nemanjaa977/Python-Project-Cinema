

class Osoba(object):
    def __init__(self, korisnicko_ime, lozinka, ime, prezime, uloga):
        self.korisnicko_ime = korisnicko_ime
        self.lozinka = lozinka
        self.ime = ime
        self.prezime = prezime
        self.uloga = uloga

    def __str__(self):
        return "{} {} {} {} {}".format(self.korisnicko_ime, self.lozinka, self.ime, self.prezime, self.uloga)

class Film(object):
    def __init__(self, naziv, zanr, trajanje, reziser, glavne_uloge, zemlja_porekla, godina_proizvodnje, skraceni_opis_filma):
        self.naziv = naziv
        self.zanr = zanr
        self.trajanje = trajanje
        self.reziser = reziser
        self.glavne_uloge = glavne_uloge
        self.zemlja_porekla = zemlja_porekla
        self.godina_proizvodnje = godina_proizvodnje
        self.skraceni_opis_filma = skraceni_opis_filma

    def __str__(self):
        return "{} {} {} {} {} {} {} {}".format(self.naziv, self.zanr, self.trajanje, self.reziser, self.glavne_uloge,
                                                self.zemlja_porekla, self.godina_proizvodnje, self.skraceni_opis_filma)

class SalaProjekcije(object):
    def __init__(self, sifra_sale, naziv_sale, broj_redova, oznaka_sedista):
        self.sifra_sale = sifra_sale
        self.naziv_sale = naziv_sale
        self.broj_redova = broj_redova
        self.oznaka_sedista = oznaka_sedista

    def __str__(self):
        return "{} {} {} {}".format(self.sifra_sale, self.naziv_sale, self.broj_redova, self.oznaka_sedista)

class BioskopskaProjekcija(object):
    def __init__(self, sifra, sala, vreme_pocetka, vreme_kraja, dani_odrzavanja, film_prikazivanje, cena_karte):
        self.sifra = sifra
        self.sala = sala
        self.vreme_pocetka = vreme_pocetka
        self.vreme_kraja = vreme_kraja
        self.dani_odrzavanja = dani_odrzavanja
        self.film_prikazivanje = film_prikazivanje
        self.cena_karte = cena_karte

    def __str__(self):
        return "{} {} {} {} {} {} {}".format(self.sifra, self.sala, self.vreme_pocetka, self.vreme_kraja,
                                             self.dani_odrzavanja, self.film_prikazivanje, self.cena_karte)

class BioskopskaKarta(object):
    def __init__(self,redni_broj, ime, prezime, korisnicko_ime, termin_projekcije, sifra_sale, red_sedista, oznaka_sedista, datum_prodaje, rezervisano_kupljeno, prodavac):
        self.redni_broj = redni_broj
        self.ime = ime
        self.prezime = prezime
        self.korisnicko_ime = korisnicko_ime
        self.termin_projekcije = termin_projekcije
        self.sifra_sale = sifra_sale
        self.red_sedista = red_sedista
        self.oznaka_sedista = oznaka_sedista
        self.datum_prodaje = datum_prodaje
        self.rezervisano_kupljeno = rezervisano_kupljeno
        self.prodavac = prodavac

    def __str__(self):
        return "{} {} {} {} {} {}".format(self.ime, self.prezime, self.korisnicko_ime, self.termin_projekcije,
                                          self.oznaka_sedista, self.datum_prodaje, self.rezervisano_kupljeno)

class TerminProjekcije(object):
    def __init__(self,sifra_termina, datum_odrzavanja):
        self.sifra_termina = sifra_termina
        self.datum_odrzavanja = datum_odrzavanja

    def __str__(self):
        return "{} {}".format(self.sifra_termina, self.datum_odrzavanja)

class Rezervacija():
    def __init__(self, redni_broj, sifra_termina, sifra_sale, red_sedista, oznaka_sedista, kupac):
        self.redni_broj = redni_broj
        self.sifra_termina = sifra_termina
        self.sifra_sale = sifra_sale
        self.red_sedista = red_sedista
        self.oznaka_sedista = oznaka_sedista
        self.kupac = kupac
